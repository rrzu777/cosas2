<div id="sidebar" class="well">
  <div class="sidebar">
    <div id="sidebar-1" class="sidebar-container" role="complementary">
      <div class="widget-area">
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
      </div>
    </div>
  </div>
</div>